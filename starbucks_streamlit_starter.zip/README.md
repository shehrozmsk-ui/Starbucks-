# Starbucks Nutrition & ML Studio

## Files required in the GitHub repository

- `app.py`
- `requirements.txt`
- `starbucks.csv`
- `decision_tree_model.joblib`
- `model_metadata.json`
- `outputs/decision_tree.png` (optional but recommended)

The CSV is loaded from the repository, so classmates do not need to upload their own copy.

## Important compatibility note

The model file and `model_metadata.json` must come from the same Kaggle training run. The app expects the metadata to include `feature_columns`, `numeric_features`, `categorical_features`, `calorie_column`, and ideally `accuracy`.

## Deploy

1. Upload the required files to one GitHub repository, preserving the `outputs` folder.
2. Open Streamlit Community Cloud and choose **Create app**.
3. Select the repository, branch, and `app.py` as the main file.
4. Deploy.

The calorie levels in this educational project are defined as Low (0–99), Medium (100–199), and High (200+). They are not official Starbucks categories. The current small dataset may not represent every menu item or current regional menu.
